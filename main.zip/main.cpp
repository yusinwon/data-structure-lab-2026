#include <QApplication> 
#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWidget>
#include <QMessageBox>
#include <QListWidget>
#include <map>
#include <vector>
#include <string>

/**
 * @brief Flight 구조체 (가중치 간선 정보 모델)
 * * 그래프 이론에서 '간선(Edge)'에 해당합니다.
 * 두 공항 정점 사이를 잇는 항공 노선 정보를 담으며, 
 * 단순 연결뿐만 아니라 '운항 시간'과 '금액'이라는 가중치(Weight) 속성을 가지고 있습니다.
 */
struct Flight {
    std::string destination; // 도착지 공항 이름 (도착 정점)
    std::string time;        // 출발/운항 시간 (가중치 속성 1)
    std::string price;       // 항공권 가격 (가중치 속성 2)
};

/**
 * @brief Airport 클래스 (정점 객체 모델)
 * * 그래프 이론에서 '정점(Vertex)'에 해당하며, 공항 하나를 객체화했습니다.
 * 객체지향의 핵심인 '캡슐화'를 준수하여 데이터를 보호하고,
 * 자신으로부터 뻗어나가는 인접 노선(간선 목록)을 내부적으로 관리(컴포지션 관계)합니다.
 */
class Airport {
private:
    std::string name;                  // 공항 이름 (정점 고유 식별자)
    std::vector<Flight> adjacentLines; // 인접한 항공 노선 목록 (간선 리스트)

public:
    // std::map 컨테이너 저장용 기본 생성자
    Airport() : name("") {}
    
    // 생성자
    Airport(const std::string& airportName) : name(airportName) {}

    // Getter 함수들
    std::string getName() const { return name; }
    
    /**
     * @brief 이 공항에서 도달 가능한 새로운 항공 경로(간선)를 추가합니다.
     * @param flight 새로 추가할 운항 노선 정보
     */
    void addFlightRoute(const Flight& flight) {
        adjacentLines.push_back(flight);
    }

    /**
     * @brief 이 공항에서 출발 가능한 모든 인접 노선 목록을 반환합니다.
     */
    const std::vector<Flight>& getRoutes() const {
        return adjacentLines;
    }
};

/**
 * @brief FlightGraph 클래스 (전체 그래프 자료구조 관리자)
 * * 공항(정점) 데이터들과 이들을 잇는 하늘길(간선)을 통합적으로 관리하는 그래프 자료구조 클래스입니다.
 * 메모리 공간과 탐색 효율성을 극대화하기 위해 '인접 리스트(Adjacency List)' 방식으로 매핑을 처리합니다.
 */
class FlightGraph {
private:
    // 공항 이름을 Key로 하고, 정점 객체를 Value로 취하는 인접 리스트 맵 구조
    std::map<std::string, Airport> adjacencyList;

public:
    FlightGraph() {}

    /**
     * @brief 그래프 구조에 새로운 공항(정점)을 추가합니다.
     */
    void addAirportNode(const std::string& name) {
        if (adjacencyList.find(name) == adjacencyList.end()) {
            adjacencyList[name] = Airport(name);
        }
    }

    /**
     * @brief 두 공항 사이에 가중치가 있는 항공 노선(방향성 간선)을 생성합니다.
     * @param from 출발 공항 (시작 정점)
     * @param to 도착 공항 (끝 정점)
     * @param time 운항 시간 (가중치 1)
     * @param price 항공권 가격 (가중치 2)
     */
    void addFlightEdge(const std::string& from, const std::string& to, const std::string& time, const std::string& price) {
        // 정점이 존재하지 않을 경우 자동 추가
        addAirportNode(from);
        addAirportNode(to);
        
        // 방향성 간선 정보 생성 및 주입
        Flight route = {to, time, price};
        adjacencyList[from].addFlightRoute(route);
    }

    /**
     * @brief 특정 출발지로부터 갈 수 있는 모든 인접 간선(항공 노선) 목록을 가져옵니다.
     * @param airportName 탐색할 출발 공항 이름
     */
    std::vector<Flight> getAirportAdjacentLines(const std::string& airportName) {
        if (adjacencyList.find(airportName) != adjacencyList.end()) {
            return adjacencyList[airportName].getRoutes();
        }
        return std::vector<Flight>();
    }

    /**
     * @brief 그래프에 등록된 모든 공항 정점들의 이름을 오름차순 목록으로 반환합니다.
     */
    std::vector<std::string> getAllAirports() const {
        std::vector<std::string> list;
        for (const auto& pair : adjacencyList) {
            list.push_back(pair.first);
        }
        return list;
    }
};

/**
 * @brief MainWindow 클래스 (GUI 뷰 및 이벤트 핸들러)
 * * 화면을 구성하고 사용자의 행동(마우스 클릭 등)을 감지하여 
 * 그래프 자료구조(`FlightGraph`) 데이터를 실시간으로 보여주고 예약 기능을 작동시키는 UI 클래스입니다.
 */
class MainWindow : public QMainWindow {
private:
    // GUI를 디자인하는 다양한 위젯 구성요소들
    QLabel* titleLabel;
    QLabel* infoLabel;
    QListWidget* airportListWidget; // 출발 공항 목록 (정점 뷰)
    QListWidget* flightListWidget;  // 도달 가능한 인접 노선 목록 (간선 뷰)
    QPushButton* bookButton;        // 예매 실행 버튼

    // 그래프 비즈니스 모델 객체 및 사용자 상태 저장 변수
    FlightGraph networkGraph;
    std::string selectedDeparture;  // 현재 사용자가 선택한 출발지 공항명

public:
    MainWindow() {
        // 1. 기본 윈도우 설정
        setWindowTitle("2026 데이터구조 최종 프로젝트 - 유신원");
        resize(650, 520);

        // 2. 그래프 원본 데이터 구축 (서버가 없는 환경이므로 코드 내에 수동 직접 매핑)
        initializeGraphData();

        // 3. UI 컴포넌트 생성 및 화면 디자인 레이아웃 배치
        QWidget* centralWidget = new QWidget(this);
        setCentralWidget(centralWidget);
        QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);
        mainLayout->setContentsMargins(15, 15, 15, 15);
        mainLayout->setSpacing(12);

        // 상단 타이틀
        titleLabel = new QLabel("<h2>🛫 JBNU 항공 노선 데이터 구조 조회 시스템</h2>");
        titleLabel->setAlignment(Qt::AlignCenter);
        mainLayout->addWidget(titleLabel);

        // 중앙 리스트 배치 영역 (수평 좌우 분할 구조)
        QHBoxLayout* contentLayout = new QHBoxLayout();
        contentLayout->setSpacing(15);
        
        // [좌측 영역] 출발 공항 리스트뷰 생성
        QVBoxLayout* leftColumn = new QVBoxLayout();
        QLabel* leftHeader = new QLabel("<h3>1. 출발 공항 (정점 선택)</h3>");
        leftHeader->setStyleSheet("font-weight: bold; color: #1e3a8a;");
        leftColumn->addWidget(leftHeader);
        
        airportListWidget = new QListWidget();
        std::vector<std::string> airports = networkGraph.getAllAirports();
        for (const auto& name : airports) {
            airportListWidget->addItem(QString::fromStdString(name));
        }
        leftColumn->addWidget(airportListWidget);
        contentLayout->addLayout(leftColumn, 1);

        // [우측 영역] 도착 인접 간선 리스트뷰 생성
        QVBoxLayout* rightColumn = new QVBoxLayout();
        QLabel* rightHeader = new QLabel("<h3>2. 도착 가능 인접 정보 (간선 노선)</h3>");
        rightHeader->setStyleSheet("font-weight: bold; color: #1e3a8a;");
        rightColumn->addWidget(rightHeader);
        
        flightListWidget = new QListWidget();
        rightColumn->addWidget(flightListWidget);
        contentLayout->addLayout(rightColumn, 1);

        mainLayout->addLayout(contentLayout);

        // 하단 상태 안내문 레이블
        infoLabel = new QLabel("출발지 목록에서 공항을 클릭하면 인접한 하늘길 정보가 탐색됩니다.");
        infoLabel->setAlignment(Qt::AlignCenter);
        infoLabel->setStyleSheet("color: #4b5563; font-style: italic; background-color: #f3f4f6; padding: 6px; border-radius: 4px;");
        mainLayout->addWidget(infoLabel);

        // 하단 예매 버튼 생성 및 예쁜 CSS 스타일링
        bookButton = new QPushButton("선택한 항공편 예매하기");
        bookButton->setMinimumHeight(40);
        bookButton->setStyleSheet("background-color: #2563eb; color: white; font-size: 14px; font-weight: bold; border-radius: 6px;");
        mainLayout->addWidget(bookButton);

        // 4. 사용자의 상호작용 신호 제어 (Qt의 핵심인 Signal과 Slot 연결)
        setupEventConnections();
    }

private:
    /**
     * @brief 그래프에 탑승할 도시 정점들과 운항 정보 간선들을 추가하여 기본 지도를 구성합니다.
     */
    void initializeGraphData() {
        // 공항 연결 구조 형성 (방향 가중치 그래프)
        networkGraph.addFlightEdge("인천 (ICN)", "뉴욕 (JFK)", "10:20 출발", "1,250,000원");
        networkGraph.addFlightEdge("인천 (ICN)", "도쿄 (NRT)", "14:05 출발", "340,000원");
        networkGraph.addFlightEdge("인천 (ICN)", "싱가포르 (SIN)", "18:40 출발", "620,000원");
        
        networkGraph.addFlightEdge("뉴욕 (JFK)", "인천 (ICN)", "11:55 출발", "1,310,000원");
        networkGraph.addFlightEdge("뉴욕 (JFK)", "런던 (LHR)", "21:30 출발", "890,000원");
        
        networkGraph.addFlightEdge("도쿄 (NRT)", "인천 (ICN)", "09:30 출발", "310,000원");
        networkGraph.addFlightEdge("도쿄 (NRT)", "싱가포르 (SIN)", "15:10 출발", "480,000원");
        
        networkGraph.addFlightEdge("싱가포르 (SIN)", "인천 (ICN)", "01:15 출발", "590,000원");
        networkGraph.addFlightEdge("싱가포르 (SIN)", "도쿄 (NRT)", "07:50 출발", "440,000원");
        
        networkGraph.addFlightEdge("런던 (LHR)", "뉴욕 (JFK)", "13:00 출발", "910,000원");
        networkGraph.addFlightEdge("런던 (LHR)", "인천 (ICN)", "16:25 출발", "1,050,000원");
    }

    /**
     * @brief 마우스 이벤트에 반응하여 데이터가 유기적으로 흐르도록 시그널과 슬롯을 엮어줍니다.
     */
    void setupEventConnections() {
        
        // [이벤트 1] 출발지 공항이 선택되거나 바뀔 때 실행되는 슬롯
        connect(airportListWidget, &QListWidget::currentTextChanged, this, [this](const QString& text) {
            // 이전 노선 목록 청소
            flightListWidget->clear();
            selectedDeparture = text.toStdString();

            // 선택된 정점으로부터 인접한 간선 데이터만 실시간 조회
            std::vector<Flight> adjacentRoutes = networkGraph.getAirportAdjacentLines(selectedDeparture);
            
            if (!adjacentRoutes.empty()) {
                infoLabel->setText(QString("출발 정점 [%1]에서 도달 가능한 운항 간선 리스트를 성공적으로 탐색했습니다.").arg(text));
                
                // 조회된 경로 데이터를 화면에 동적으로 렌더링
                for (const auto& flight : adjacentRoutes) {
                    QString displayItem = QString("🛫 %1 | ⏰ %2 | 💰 %3")
                        .arg(QString::fromStdString(flight.destination))
                        .arg(QString::fromStdString(flight.time))
                        .arg(QString::fromStdString(flight.price));
                    flightListWidget->addItem(displayItem);
                }
            } else {
                infoLabel->setText("해당 공항에서 직항으로 갈 수 있는 노선이 존재하지 않습니다.");
            }
        });

        // [이벤트 2] 예매하기 버튼을 누를 때 작동하는 슬롯 (방어적 예외처리 포함)
        connect(bookButton, &QPushButton::clicked, this, [this]() {
            QListWidgetItem* activeItem = flightListWidget->currentItem();
            
            // 아무 항공편도 선택하지 않은 채 버튼을 누른 경우의 예외 방어
            if (!activeItem) {
                QMessageBox::warning(this, "선택 오류", "항공권을 조회하신 후, 오른쪽 도착지 목록에서 예약할 노선을 클릭해주세요.");
                return;
            }

            // 올바르게 선택된 경우 예매 성공 알림창 띄우기
            QMessageBox::information(this, "항공권 예매 성공",
                QString("항공권 예약이 성공적으로 확정되었습니다!\n\n출발 공항: %1\n상세 정보: %2\n\n즐겁고 안전한 여행이 되시길 바랍니다.")
                .arg(QString::fromStdString(selectedDeparture))
                .arg(activeItem->text()));
        });
    }
};

/**
 * @brief C++ 프로그램의 실제 진입점(Entry Point)인 main 함수입니다.
 * Qt 애플리케이션 수명주기를 생성하고 메인 윈도우를 화면에 띄워 이벤트를 시작합니다.
 */
int main(int argc, char *argv[]) {
    QApplication app(argc, argv); // Qt 어플리케이션 객체 생성
    
    MainWindow window;            // 우리가 디자인한 메인 윈도우 객체 생성
    window.show();                // 화면에 표시
    
    return app.exec();            // 이벤트 루프 시작 및 프로그램 종료 대기
}
